# OAuth

To run the project you need to get the credential.json file.
watch the tutorial here : https://youtu.be/cQAbGqoZmBM

run npm i then npm start to run the project
