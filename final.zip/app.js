const express = require('express');
const { google } = require('googleapis');
const dotenv = require('dotenv');
const path = require('path');

const fs = require('fs');


const app = express();
dotenv.config();

app.use(express.static(path.join(__dirname, 'build')));

//cors related stuff
const cors = require('cors');
app.use(cors({
    origin : 'http://localhost:3000',
    methods : ['GET','POST','PUT','DELETE'],
    allowedHeaders : ['Content-Type', 'Authorization']
}));
//-------

const oAuth2Client = new google.auth.OAuth2(
    process.env.CLIENT_ID,
    process.env.CLIENT_SECRET,
    process.env.REDIRECT_URI
)

const drive = google.drive({ version: 'v3', auth: oAuth2Client });


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.get('/status', (req, res) => {
    const creds = fs.readFileSync("creds.json");
    res.send(JSON.stringify(JSON.parse(creds)));
});


app.get('/auth/google', (req, res) => {
    const url = oAuth2Client.generateAuthUrl({
        access_type : "offline",
        scope : [
            "https://www.googleapis.com/auth/drive.metadata.readonly",
            "https://www.googleapis.com/auth/userinfo.profile", 
            "https://www.googleapis.com/auth/drive"
        ]
    })
    res.header('Access-Control-Allow-Credentials', true);
    res.redirect(url);
});

app.get('/redirect', (req, res) => {
    const { code } = req.query;
    oAuth2Client.getToken(code, (err,token) => {
        
        if (err){ res.send("Error-------Write something meaningful later")}        

        oAuth2Client.setCredentials(token);
        fs.writeFileSync("creds.json", JSON.stringify(token));
        // res.header('Access-Control-Allow-Credentials', true);
        res.redirect("/"); //replace this with: res.redirect("http://localhost:3000/")
    });
});


app.get('/files/google', (req, res) => {

    drive.files.list({}, (err, response) => res.send(response.data.files)); 
});

app.get('/fileDetails', (req, res) => {

    drive.files.get({fileId : req.query.fileId, fields : "name,id,size,mimeType"}, (err,response) => res.send(response.data));
});

app.get('/info/google', (req, res) => {
    
    drive.about.get({fields : "storageQuota"}, (err,response) => {
        res.send({
            "totalStorageInMb" : response.data.storageQuota.limit/1048576,
            "usedStorageInMb" : response.data.storageQuota.usage/1048576,
            "availableStorageInMb" : (response.data.storageQuota.limit-response.data.storageQuota.usage)/1048576
        });
    })

});

app.get('/revoke/google', (req, res) => {
    const creds = fs.readFileSync("creds.json");
    oAuth2Client.revokeToken(JSON.parse(creds).access_token);
    fs.writeFileSync("creds.json", JSON.stringify(null));
    res.send({revokeStatus : true});
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(`Server Started ${PORT}`));